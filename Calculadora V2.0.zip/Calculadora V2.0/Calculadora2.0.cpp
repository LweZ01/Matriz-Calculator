#include <stdio.h>
#include <stdlib.h>

// Variables
int a; 
int e, f, g, h;
int i, j, k; 

    int** b = NULL; // Matriz 1
    int** c = NULL; // Matriz 2  
    int** d = NULL; // Resultado

int main() {  

    printf("Bienvenido a la Calculadora Matricial V2.0!\n");
    printf("Ahora con soporte para matrices de tamano dinamico!\n");
    
    do {
        // Menu principal
        printf("\n=== CALCULADORA MATRICIAL V2.0 ===\n");
        printf("1. Suma de matrices\n");
        printf("2. Resta de matrices\n");
        printf("3. Multiplicacion de matrices\n");
        printf("4. Salir del programa\n");
        printf("Seleccione una opcion: ");
        
        while (scanf("%d", &a) != 1) {
            printf("Error: Debe ingresar un numero. Seleccione una opcion: ");
            while (getchar() != '\n');
        }
        
        switch (a) {
            case 1: // Suma
                printf("\n=== SUMA DE MATRICES ===\n");
                
                // Tama�o de la matriz 1
                printf("\nMatriz 1:\n");
                printf("Ingrese el numero de filas: ");
                while (scanf("%d", &e) != 1 || e <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                printf("Ingrese el numero de columnas: ");
                while (scanf("%d", &f) != 1 || f <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                
                // Matriz 1
                b = (int**)malloc(e * sizeof(int*));
                if (b == NULL) {
                    printf("Error: No se pudo asignar memoria para la Matriz 1.\n");
                    printf("\nPresione Enter para continuar...");
                    getchar();
                    getchar();
                    system("cls");
                    break;
                }
                for (i = 0; i < e; i++) {
                    b[i] = (int*)malloc(f * sizeof(int));
                    if (b[i] == NULL) {
                        printf("Error: No se pudo asignar memoria para la fila %d de la Matriz 1.\n", i + 1);
                        for (j = 0; j < i; j++) {
                            free(b[j]);
                        }
                        free(b);
                        b = NULL;
                        printf("\nPresione Enter para continuar...");
                        getchar();
                        getchar();
                        system("cls");
                        break;
                    }
                }
                if (b == NULL) break; 
                
                printf("\nIngrese los elementos de la Matriz 1:\n");
                for (i = 0; i < e; i++) {
                    for (j = 0; j < f; j++) {
                        printf("Elemento [%d][%d]: ", i + 1, j + 1);
                        while (scanf("%d", &b[i][j]) != 1) {
                            printf("Error: Debe ingresar un numero. Elemento [%d][%d]: ", i + 1, j + 1);
                            while (getchar() != '\n');
                        }
                    }
                }
                
                // Matriz 2
                printf("\nMatriz 2:\n");
                printf("Ingrese el numero de filas: ");
                while (scanf("%d", &g) != 1 || g <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                printf("Ingrese el numero de columnas: ");
                while (scanf("%d", &h) != 1 || h <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }

                c = (int**)malloc(g * sizeof(int*));
                if (c == NULL) {
                    printf("Error: No se pudo asignar memoria para la Matriz 2.\n");
                    for (i = 0; i < e; i++) {
                        free(b[i]);
                    }
                    free(b);
                    b = NULL;
                    printf("\nPresione Enter para continuar...");
                    getchar();
                    getchar();
                    system("cls");
                    break;
                }
                for (i = 0; i < g; i++) {
                    c[i] = (int*)malloc(h * sizeof(int));
                    if (c[i] == NULL) {
                        printf("Error: No se pudo asignar memoria para la fila %d de la Matriz 2.\n", i + 1);
                        for (j = 0; j < i; j++) {
                            free(c[j]);
                        }
                        free(c);
                        c = NULL;
                        for (i = 0; i < e; i++) {
                            free(b[i]);
                        }
                        free(b);
                        b = NULL;
                        printf("\nPresione Enter para continuar...");
                        getchar();
                        getchar();
                        system("cls");
                        break;
                    }
                }
                if (c == NULL) break; 

                printf("\nIngrese los elementos de la Matriz 2:\n");
                for (i = 0; i < g; i++) {
                    for (j = 0; j < h; j++) {
                        printf("Elemento [%d][%d]: ", i + 1, j + 1);
                        while (scanf("%d", &c[i][j]) != 1) {
                            printf("Error: Debe ingresar un numero. Elemento [%d][%d]: ", i + 1, j + 1);
                            while (getchar() != '\n');
                        }
                    }
                }
                
                // Grafica de las matrices
                printf("\nMatriz 1:\n");
                for (i = 0; i < e; i++) {
                    printf("[ ");
                    for (j = 0; j < f; j++) {
                        printf("%4d ", b[i][j]);
                    }
                    printf("]\n");
                }
                
                printf("\nMatriz 2:\n");
                for (i = 0; i < g; i++) {
                    printf("[ ");
                    for (j = 0; j < h; j++) {
                        printf("%4d ", c[i][j]);
                    }
                    printf("]\n");
                }
                
                // Verificar si las dimensiones son compatibles para suma
                if (e != g || f != h) {
                    printf("\nError: No es posible realizar la suma.\n");
                    printf("Causa: Las matrices deben tener las mismas dimensiones.\n");
                    printf("Matriz 1: %dx%d, Matriz 2: %dx%d\n", e, f, g, h);
                } else {
                    d = (int**)malloc(e * sizeof(int*));
                    if (d == NULL) {
                        printf("Error: No se pudo asignar memoria para el resultado.\n");
                    } else {
                        for (i = 0; i < e; i++) {
                            d[i] = (int*)malloc(f * sizeof(int));
                            if (d[i] == NULL) {
                                printf("Error: No se pudo asignar memoria para la fila %d del resultado.\n", i + 1);
                                for (j = 0; j < i; j++) {
                                    free(d[j]);
                                }
                                free(d);
                                d = NULL;
                                break;
                            }
                        }
                        
                        if (d != NULL) {
                            // Realizar la suma
                            for (i = 0; i < e; i++) {
                                for (j = 0; j < f; j++) {
                                    d[i][j] = b[i][j] + c[i][j];
                                }
                            }
                            
                            // Resultado
                            printf("\nResultado de la suma:\n");
                            for (i = 0; i < e; i++) {
                                printf("[ ");
                                for (j = 0; j < f; j++) {
                                    printf("%4d ", d[i][j]);
                                }
                                printf("]\n");
                            }
                            
                            // Limpia matriz resultado
                            for (i = 0; i < e; i++) {
                                free(d[i]);
                            }
                            free(d);
                            d = NULL;
                        }
                    }
                }
                
                // Liberar matrices
                for (i = 0; i < e; i++) {
                    free(b[i]);
                }
                free(b);
                b = NULL;
                
                for (i = 0; i < g; i++) {
                    free(c[i]);
                }
                free(c);
                c = NULL;
                
                printf("\nPresione Enter para continuar...");
                getchar();
                getchar();
                system("cls");
                break;
                
            case 2: // Resta
                printf("\n=== RESTA DE MATRICES ===\n");
                
                // Dimensiones de la Matriz 1
                printf("\nMatriz 1:\n");
                printf("Ingrese el numero de filas: ");
                while (scanf("%d", &e) != 1 || e <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                printf("Ingrese el numero de columnas: ");
                while (scanf("%d", &f) != 1 || f <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                
                // Matriz 1
                b = (int**)malloc(e * sizeof(int*));
                if (b == NULL) {
                    printf("Error: No se pudo asignar memoria para la Matriz 1.\n");
                    printf("\nPresione Enter para continuar...");
                    getchar();
                    getchar();
                    system("cls");
                    break;
                }
                for (i = 0; i < e; i++) {
                    b[i] = (int*)malloc(f * sizeof(int));
                    if (b[i] == NULL) {
                        printf("Error: No se pudo asignar memoria para la fila %d de la Matriz 1.\n", i + 1);
                        for (j = 0; j < i; j++) {
                            free(b[j]);
                        }
                        free(b);
                        b = NULL;
                        printf("\nPresione Enter para continuar...");
                        getchar();
                        getchar();
                        system("cls");
                        break;
                    }
                }
                if (b == NULL) break;
                
                // Elementos de la Matriz 1
                printf("\nIngrese los elementos de la Matriz 1:\n");
                for (i = 0; i < e; i++) {
                    for (j = 0; j < f; j++) {
                        printf("Elemento [%d][%d]: ", i + 1, j + 1);
                        while (scanf("%d", &b[i][j]) != 1) {
                            printf("Error: Debe ingresar un numero. Elemento [%d][%d]: ", i + 1, j + 1);
                            while (getchar() != '\n');
                        }
                    }
                }
                
                // Matriz 2
                printf("\nMatriz 2:\n");
                printf("Ingrese el numero de filas: ");
                while (scanf("%d", &g) != 1 || g <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                printf("Ingrese el numero de columnas: ");
                while (scanf("%d", &h) != 1 || h <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }

                c = (int**)malloc(g * sizeof(int*));
                if (c == NULL) {
                    printf("Error: No se pudo asignar memoria para la Matriz 2.\n");
                    for (i = 0; i < e; i++) {
                        free(b[i]);
                    }
                    free(b);
                    b = NULL;
                    printf("\nPresione Enter para continuar...");
                    getchar();
                    getchar();
                    system("cls");
                    break;
                }
                for (i = 0; i < g; i++) {
                    c[i] = (int*)malloc(h * sizeof(int));
                    if (c[i] == NULL) {
                        printf("Error: No se pudo asignar memoria para la fila %d de la Matriz 2.\n", i + 1);
                        for (j = 0; j < i; j++) {
                            free(c[j]);
                        }
                        free(c);
                        c = NULL;
                        for (i = 0; i < e; i++) {
                            free(b[i]);
                        }
                        free(b);
                        b = NULL;
                        printf("\nPresione Enter para continuar...");
                        getchar();
                        getchar();
                        system("cls");
                        break;
                    }
                }
                if (c == NULL) break;
                
                // Elementos de la Matriz 2
                printf("\nIngrese los elementos de la Matriz 2:\n");
                for (i = 0; i < g; i++) {
                    for (j = 0; j < h; j++) {
                        printf("Elemento [%d][%d]: ", i + 1, j + 1);
                        while (scanf("%d", &c[i][j]) != 1) {
                            printf("Error: Debe ingresar un numero. Elemento [%d][%d]: ", i + 1, j + 1);
                            while (getchar() != '\n');
                        }
                    }
                }
                
                // Grafica de las matrices
                printf("\nMatriz 1:\n");
                for (i = 0; i < e; i++) {
                    printf("[ ");
                    for (j = 0; j < f; j++) {
                        printf("%4d ", b[i][j]);
                    }
                    printf("]\n");
                }
                
                printf("\nMatriz 2:\n");
                for (i = 0; i < g; i++) {
                    printf("[ ");
                    for (j = 0; j < h; j++) {
                        printf("%4d ", c[i][j]);
                    }
                    printf("]\n");
                }
                
                // Verifica si son compatibles para resta
                if (e != g || f != h) {
                    printf("\nError: No es posible realizar la resta.\n");
                    printf("Causa: Las matrices deben tener las mismas dimensiones.\n");
                    printf("Matriz 1: %dx%d, Matriz 2: %dx%d\n", e, f, g, h);
                } else {
                    d = (int**)malloc(e * sizeof(int*));
                    if (d == NULL) {
                        printf("Error: No se pudo asignar memoria para el resultado.\n");
                    } else {
                        for (i = 0; i < e; i++) {
                            d[i] = (int*)malloc(f * sizeof(int));
                            if (d[i] == NULL) {
                                printf("Error: No se pudo asignar memoria para la fila %d del resultado.\n", i + 1);
                                for (j = 0; j < i; j++) {
                                    free(d[j]);
                                }
                                free(d);
                                d = NULL;
                                break;
                            }
                        }
                        
                        if (d != NULL) {
                            for (i = 0; i < e; i++) {
                                for (j = 0; j < f; j++) {
                                    d[i][j] = b[i][j] - c[i][j];
                                }
                            }
                            
                            // Resultado
                            printf("\nResultado de la resta:\n");
                            for (i = 0; i < e; i++) {
                                printf("[ ");
                                for (j = 0; j < f; j++) {
                                    printf("%4d ", d[i][j]);
                                }
                                printf("]\n");
                            }
                            
                            for (i = 0; i < e; i++) {
                                free(d[i]);
                            }
                            free(d);
                            d = NULL;
                        }
                    }
                }
                
                for (i = 0; i < e; i++) {
                    free(b[i]);
                }
                free(b);
                b = NULL;
                
                for (i = 0; i < g; i++) {
                    free(c[i]);
                }
                free(c);
                c = NULL;
                
                printf("\nPresione Enter para continuar...");
                getchar();
                getchar();
                system("cls");
                break;
                
            case 3: // Multiplicacion
                printf("\n=== MULTIPLICACION DE MATRICES ===\n");
                
                // Matriz 1
                printf("\nMatriz 1:\n");
                printf("Ingrese el numero de filas: ");
                while (scanf("%d", &e) != 1 || e <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                printf("Ingrese el numero de columnas: ");
                while (scanf("%d", &f) != 1 || f <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
				}
                b = (int**)malloc(e * sizeof(int*));
                if (b == NULL) {
                    printf("Error: No se pudo asignar memoria para la Matriz 1.\n");
                    printf("\nPresione Enter para continuar...");
                    getchar();
                    getchar();
                    system("cls");
                    break;
                }
                for (i = 0; i < e; i++) {
                    b[i] = (int*)malloc(f * sizeof(int));
                    if (b[i] == NULL) {
                        printf("Error: No se pudo asignar memoria para la fila %d de la Matriz 1.\n", i + 1);
                        for (j = 0; j < i; j++) {
                            free(b[j]);
                        }
                        free(b);
                        b = NULL;
                        printf("\nPresione Enter para continuar...");
                        getchar();
                        getchar();
                        system("cls");
                        break;
                    }
                }
                if (b == NULL) break;
                
                // elementos de la Matriz 1
                printf("\nIngrese los elementos de la Matriz 1:\n");
                for (i = 0; i < e; i++) {
                    for (j = 0; j < f; j++) {
                        printf("Elemento [%d][%d]: ", i + 1, j + 1);
                        while (scanf("%d", &b[i][j]) != 1) {
                            printf("Error: Debe ingresar un numero. Elemento [%d][%d]: ", i + 1, j + 1);
                            while (getchar() != '\n');
                        }
                    }
                }
                
                // Matriz 2
                printf("\nMatriz 2:\n");
                printf("Ingrese el numero de filas: ");
                while (scanf("%d", &g) != 1 || g <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                printf("Ingrese el numero de columnas: ");
                while (scanf("%d", &h) != 1 || h <= 0) {
                    printf("Error: Debe ingresar un numero positivo: ");
                    while (getchar() != '\n');
                }
                c = (int**)malloc(g * sizeof(int*));
                if (c == NULL) {
                    printf("Error: No se pudo asignar memoria para la Matriz 2.\n");
                    for (i = 0; i < e; i++) {
                        free(b[i]);
                    }
                    free(b);
                    b = NULL;
                    printf("\nPresione Enter para continuar...");
                    getchar();
                    getchar();
                    system("cls");
                    break;
                }
                for (i = 0; i < g; i++) {
                    c[i] = (int*)malloc(h * sizeof(int));
                    if (c[i] == NULL) {
                        printf("Error: No se pudo asignar memoria para la fila %d de la Matriz 2.\n", i + 1);
                        for (j = 0; j < i; j++) {
                            free(c[j]);
                        }
                        free(c);
                        c = NULL;
                        for (i = 0; i < e; i++) {
                            free(b[i]);
                        }
                        free(b);
                        b = NULL;
                        printf("\nPresione Enter para continuar...");
                        getchar();
                        getchar();
                        system("cls");
                        break;
                    }
                }
                if (c == NULL) break;
                
                // elementos de la Matriz 2
                printf("\nIngrese los elementos de la Matriz 2:\n");
                for (i = 0; i < g; i++) {
                    for (j = 0; j < h; j++) {
                        printf("Elemento [%d][%d]: ", i + 1, j + 1);
                        while (scanf("%d", &c[i][j]) != 1) {
                            printf("Error: Debe ingresar un numero. Elemento [%d][%d]: ", i + 1, j + 1);
                            while (getchar() != '\n');
                        }
                    }
                }
                
                // grafica las matrices ingresadas
                printf("\nMatriz 1:\n");
                for (i = 0; i < e; i++) {
                    printf("[ ");
                    for (j = 0; j < f; j++) {
                        printf("%4d ", b[i][j]);
                    }
                    printf("]\n");
                }
                
                printf("\nMatriz 2:\n");
                for (i = 0; i < g; i++) {
                    printf("[ ");
                    for (j = 0; j < h; j++) {
                        printf("%4d ", c[i][j]);
                    }
                    printf("]\n");
                }
                
                // Verifica si las dimensiones son compatibles para multiplicacion
                if (f != g) {
                    printf("\nError: No es posible realizar la multiplicacion.\n");
                    printf("Causa: El numero de columnas de la primera matriz debe ser igual\n");
                    printf("       al numero de filas de la segunda matriz.\n");
                    printf("Matriz 1: %dx%d, Matriz 2: %dx%d\n", e, f, g, h);
                } else {
                    d = (int**)malloc(e * sizeof(int*));
                    if (d == NULL) {
                        printf("Error: No se pudo asignar memoria para el resultado.\n");
                    } else {
                        for (i = 0; i < e; i++) {
                            d[i] = (int*)malloc(h * sizeof(int));
                            if (d[i] == NULL) {
                                printf("Error: No se pudo asignar memoria para la fila %d del resultado.\n", i + 1);
                                for (j = 0; j < i; j++) {
                                    free(d[j]);
                                }
                                free(d);
                                d = NULL;
                                break;
                            }
                        }
                        
                        if (d != NULL) {
                            for (i = 0; i < e; i++) {
                                for (j = 0; j < h; j++) {
                                    d[i][j] = 0;
                                    for (k = 0; k < f; k++) {
                                        d[i][j] += b[i][k] * c[k][j];
                                    }
                                }
                            }
                            
                            // Resultado
                            printf("\nResultado de la multiplicacion:\n");
                            for (i = 0; i < e; i++) {
                                printf("[ ");
                                for (j = 0; j < h; j++) {
                                    printf("%4d ", d[i][j]);
                                }
                                printf("]\n");
                            }
                            
                            for (i = 0; i < e; i++) {
                                free(d[i]);
                            }
                            free(d);
                            d = NULL;
                        }
                    }
                }
                
                for (i = 0; i < e; i++) {
                    free(b[i]);
                }
                free(b);
                b = NULL;
                
                for (i = 0; i < g; i++) {
                    free(c[i]);
                }
                free(c);
                c = NULL;
                
                printf("\nPresione Enter para continuar...");
                getchar();
                getchar();
                system("cls");
                break;
                
            case 4: // Salir del programa
                printf("\n�Gracias por usar la Calculadora Matricial V2.0!\n");
                printf("�Hasta luego!\n");
                break;
                
            default:
                printf("\nOpcion no valida. Por favor, seleccione una opcion del 1 al 4.\n");
                printf("\nPresione Enter para continuar...");
                getchar();
                getchar();
                system("cls");
                break;
        }
        
    } while (a != 4);
    
    // Limpieza de memoria 
    if (b != NULL) {
        for (i = 0; i < e; i++) {
            if (b[i] != NULL) free(b[i]);
        }
        free(b);
    }
    if (c != NULL) {
        for (i = 0; i < g; i++) {
            if (c[i] != NULL) free(c[i]);
        }
        free(c);
    }
    if (d != NULL) {
        for (i = 0; i < e; i++) {
            if (d[i] != NULL) free(d[i]);
        }
        free(d);
    }
    
    return 0;
}
